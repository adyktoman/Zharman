import model from 'parket';

const CharsStore = model('CharsStore', {
  initial: () => ({
    chars: [],
    char: {
      name: 'Unnamed',
      points: 0,
      race: 0, // 0: Archer, 1: Knight, 2: Mage
      stats: {
        hp: 0,
        sp: 0,
        str: 0,
        def: 0,
        int: 0
      }
    }
  }),
  actions: state => ({
    clearChar() {
      state.char = {
        name: 'Unnamed',
        points: 0,
        race: 0,
        stats: {
          hp: 0,
          sp: 0,
          str: 0,
          def: 0,
          int: 0
        }
      }
    },
    getChars() {
      state.chars.forEach( obj => console.log(obj));
      return state.chars;
    },
    setCharName (name) {
      state.char.name = name;
      console.log('Updated Char!', state.char.stats, state.char.points);
    },
    setCharRace(index) {
      state.char.race = index
      console.log('Updated Char!', state.char.stats, state.char.points);
    },
    setCharStat(stat, value) {
      state.char.stats[stat] = parseInt(value, 10) | 0;
      state.char.points = state.char.stats.hp + state.char.stats.sp +
      state.char.stats.str + state.char.stats.def + state.char.stats.int;
      console.log('Updated Char!', state.char.stats, state.char.points);
    },
    addChar(char) {
      state.chars.push(char);
    },
    removeChar(char) {
      state.chars = state.chars.filter(current => current.name !== char.name)
    },
  })
});

export default CharsStore;
