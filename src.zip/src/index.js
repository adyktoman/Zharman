import '../node_modules/bootstrap/dist/css/bootstrap.css';
import './styles/';

import 'bootstrap';

import App from './app/app';
export default App;
