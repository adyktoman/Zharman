const BattlePage = () => (
  <section>
    <h1>Battle Page</h1>
  </section>
);

export default BattlePage;
