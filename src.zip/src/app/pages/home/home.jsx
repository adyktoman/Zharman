const HomePage = () => (
  <section>
    <h1>Home Page</h1>
  </section>
);

export default HomePage;
