import { connect } from 'parket/preact';
import { Component } from 'preact';

import Modal from '../../components/modal';

@connect
export default class CharEditorModal extends Component {
  render ({ store, onChange, onCreate }) {
    return (
      <Modal id="charEditorModal" title="Add a new char">
        <div class="modal-body">
          <form id="newCharForm">
            <div class={ 'border-bottom mb-3 py-1 ' + (store.char.points !== 20 && 'text-danger') }>
              Available points: { 20 - store.char.points }
            </div>
            <div class="form-row">
              <div class="form-group col-sm-6">
                Name: <input class="form-control" required autofocus onInput={ (e) => store.setCharName(e.target.value) } type="text" value={ store.char.name } placeholder="Unknown" />
              </div>
              <div class="form-group col-sm-3">
                HP: <input class="form-control" onInput={ (e) => store.setCharStat('hp', e.target.value) } type="number" value={ store.char.stats.hp } />
              </div>
              <div class="form-group col-sm-3">
                SP: <input class="form-control" onInput={ (e) => store.setCharStat('sp', e.target.value) } type="number" value={ store.char.stats.sp } />
              </div>
              <div class="form-group col-sm-4">
                STR: <input class="form-control" onInput={ (e) => store.setCharStat('str', e.target.value) } type="number" value={ store.char.stats.str } />
              </div>
              <div class="form-group col-sm-4">
                DEX: <input class="form-control" onInput={ (e) => store.setCharStat('def', e.target.value) } type="number" value={ store.char.stats.def } />
              </div>
              <div class="form-group col-sm-4">
                WIS: <input class="form-control" onInput={ (e) => store.setCharStat('int', e.target.value) } type="number" value={ store.char.stats.int } />
              </div>
              <div class="form-group col">
                <div class="btn-group btn-group-toggle">
                  <label class="btn btn-secondary">
                    <input type="radio" onChange={ () => store.setCharRace(0) } checked={ store.char.race === 0 } /> Archer
                  </label>
                  <label class="btn btn-secondary">
                    <input type="radio" onChange={ () => store.setCharRace(1) } checked={ store.char.race === 1 } /> Knight
                  </label>
                  <label class="btn btn-secondary">
                    <input type="radio" onChange={ () => store.setCharRace(2) } checked={ store.char.race === 2 } /> Mage
                  </label>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" onClick={ onCreate } disabled={ store.char.points !== 20 } >Save changes</button>
        </div>
      </Modal>
    );
  }
}
