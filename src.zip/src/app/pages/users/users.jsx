const UsersPage = () => (
  <section>
    <h1>Users Page</h1>
  </section>
);

export default UsersPage;
